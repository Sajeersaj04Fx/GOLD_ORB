Expert Advisor: GOLD_ORB
Timeframe: 1HR

See Test cases for Tested Data.
Profitable on Bull Market


Instruction:
1. Copy the GOLD_ORB Folder to MetaTrader Directory
2. Compile the program
3. Load the default inputs
4. Perform Initial test Recalibration (see Test Cases)